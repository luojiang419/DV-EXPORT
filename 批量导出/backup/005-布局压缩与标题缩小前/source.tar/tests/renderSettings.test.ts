import { describe, expect, it } from "vitest";
import { buildResolveRenderSettings } from "../src/core/renderSettings";

describe("render settings", () => {
  it("builds resolve render settings from profile", () => {
    const result = buildResolveRenderSettings(
      {
        presetName: "H264 Master",
        format: "mp4",
        codec: "h264",
        resolution: { width: 3840, height: 2160 },
        frameRate: 25,
        exportVideo: true,
        exportAudio: false
      },
      "D:/Exports",
      "Episode01"
    );

    expect(result).toEqual({
      SelectAllFrames: true,
      TargetDir: "D:/Exports",
      CustomName: "Episode01",
      ExportVideo: true,
      ExportAudio: false,
      FormatWidth: 3840,
      FormatHeight: 2160,
      FrameRate: 25,
      AudioCodec: undefined,
      AudioBitDepth: undefined,
      AudioSampleRate: undefined,
      ExportAlpha: undefined
    });
  });
});
