import type { TimelineEntry } from "../../types/models";

interface TimelineListProps {
  timelines: TimelineEntry[];
  selectedIds: string[];
  onSelect(timelineId: string, modifiers: { ctrlKey: boolean; shiftKey: boolean }): void;
}

export function TimelineList({ timelines, selectedIds, onSelect }: TimelineListProps) {
  if (timelines.length === 0) {
    return <div className="empty-panel">当前文件夹内没有可识别的时间线。</div>;
  }

  return (
    <div className="timeline-list">
      {timelines.map((timeline, index) => {
        const selected = selectedIds.includes(timeline.id);
        return (
          <button
            key={timeline.id}
            type="button"
            className={`timeline-list__item ${selected ? "is-active" : ""}`}
            onClick={(event) => onSelect(timeline.id, { ctrlKey: event.ctrlKey || event.metaKey, shiftKey: event.shiftKey })}
          >
            <span className="timeline-list__index">{String(index + 1).padStart(2, "0")}</span>
            <span className="timeline-list__name">{timeline.name}</span>
          </button>
        );
      })}
    </div>
  );
}
