import type { RenderProfile } from "../types/models";

export interface ResolveRenderSettings {
  SelectAllFrames: true;
  TargetDir: string;
  CustomName: string;
  ExportVideo: boolean;
  ExportAudio: boolean;
  FormatWidth: number;
  FormatHeight: number;
  FrameRate: number;
  AudioCodec?: string;
  AudioBitDepth?: number;
  AudioSampleRate?: number;
  ExportAlpha?: boolean;
}

export function buildResolveRenderSettings(
  profile: RenderProfile,
  targetDir: string,
  customName: string
): ResolveRenderSettings {
  return {
    SelectAllFrames: true,
    TargetDir: targetDir,
    CustomName: customName,
    ExportVideo: profile.exportVideo,
    ExportAudio: profile.exportAudio,
    FormatWidth: profile.resolution.width,
    FormatHeight: profile.resolution.height,
    FrameRate: profile.frameRate,
    AudioCodec: profile.audioCodec,
    AudioBitDepth: profile.audioBitDepth,
    AudioSampleRate: profile.audioSampleRate,
    ExportAlpha: profile.exportAlpha
  };
}
