"use strict";

const path = require("path");
const { contextBridge, ipcRenderer } = require("electron");

const pluginId = "com.dvexport.batch-export";
const workflowIntegrationPath = path.join(__dirname, "WorkflowIntegration.node");

let workflowIntegration = null;
let resolve = null;
let initialized = false;

function safeCall(fn, fallback = null) {
  try {
    return fn();
  } catch (error) {
    return fallback;
  }
}

function requireWorkflowIntegration() {
  if (!workflowIntegration) {
    workflowIntegration = require(workflowIntegrationPath);
  }

  return workflowIntegration;
}

function initializeResolve() {
  if (initialized && resolve) {
    return resolve;
  }

  const integration = requireWorkflowIntegration();
  const success = integration.Initialize(pluginId);
  if (!success) {
    throw new Error("Workflow Integration 初始化失败，请确认当前为 Resolve Studio 且插件目录包含 WorkflowIntegration.node。");
  }

  resolve = integration.GetResolve();
  initialized = true;
  return resolve;
}

function getProjectContext() {
  const app = initializeResolve();
  const projectManager = app.GetProjectManager();
  const project = projectManager && projectManager.GetCurrentProject ? projectManager.GetCurrentProject() : null;

  if (!project) {
    throw new Error("当前没有打开的工程。");
  }

  return {
    app,
    projectManager,
    project
  };
}

function getVersionInfo() {
  const app = initializeResolve();
  const productName = safeCall(() => app.GetProductName(), "DaVinci Resolve");
  const version = safeCall(() => app.GetVersion(), []);
  const versionString = safeCall(() => app.GetVersionString(), Array.isArray(version) ? version.join(".") : "");
  const majorVersion = Array.isArray(version) && version.length > 0 ? Number(version[0]) : Number.parseInt(String(versionString).split(".")[0] || "0", 10);

  return {
    productName,
    versionString,
    majorVersion,
    isStudio: String(productName).toLowerCase().includes("studio")
  };
}

function normalizeList(value) {
  if (Array.isArray(value)) {
    return value;
  }

  if (!value) {
    return [];
  }

  return Object.values(value);
}

function buildFolderTree(folder) {
  return {
    id: safeCall(() => folder.GetUniqueId(), ""),
    name: safeCall(() => folder.GetName(), "未命名文件夹"),
    children: normalizeList(safeCall(() => folder.GetSubFolderList(), [])).map((child) => buildFolderTree(child))
  };
}

function findFolderById(folder, targetId) {
  if (!folder) {
    return null;
  }

  if (safeCall(() => folder.GetUniqueId(), "") === targetId) {
    return folder;
  }

  const subFolders = normalizeList(safeCall(() => folder.GetSubFolderList(), []));
  for (const subFolder of subFolders) {
    const match = findFolderById(subFolder, targetId);
    if (match) {
      return match;
    }
  }

  return null;
}

function getTimelineMediaPoolItem(timeline) {
  const candidate = safeCall(() => timeline.GetMediaPoolItem && timeline.GetMediaPoolItem(), null);
  return candidate || null;
}

function getClipType(clip) {
  const typeFromProperty = safeCall(() => clip.GetClipProperty && clip.GetClipProperty("Type"), "");
  const fallbackType = safeCall(() => clip.GetMetadata && clip.GetMetadata("Type"), "");
  return String(typeFromProperty || fallbackType || "").toLowerCase();
}

function scanProjectTimelines(project) {
  const count = safeCall(() => project.GetTimelineCount(), 0);
  const timelines = [];

  for (let index = 1; index <= count; index += 1) {
    const timeline = safeCall(() => project.GetTimelineByIndex(index), null);
    if (!timeline) {
      continue;
    }

    const mediaPoolItem = getTimelineMediaPoolItem(timeline);
    timelines.push({
      id: safeCall(() => timeline.GetUniqueId(), ""),
      name: safeCall(() => timeline.GetName(), `时间线-${index}`),
      mediaPoolItemId: mediaPoolItem ? safeCall(() => mediaPoolItem.GetMediaId(), "") : "",
      timeline
    });
  }

  return timelines;
}

function listTimelinesInFolder(folderId) {
  const { project } = getProjectContext();
  const mediaPool = project.GetMediaPool();
  const rootFolder = mediaPool.GetRootFolder();
  const targetFolder = findFolderById(rootFolder, folderId);

  if (!targetFolder) {
    throw new Error("未找到指定的媒体池文件夹。");
  }

  const timelines = scanProjectTimelines(project);
  const matchedByMediaId = new Map();
  for (const timeline of timelines) {
    if (timeline.mediaPoolItemId) {
      matchedByMediaId.set(timeline.mediaPoolItemId, timeline);
    }
  }

  const clips = normalizeList(safeCall(() => targetFolder.GetClipList(), []));
  const usedTimelineIds = new Set();
  const entries = [];

  for (const clip of clips) {
    const mediaId = safeCall(() => clip.GetMediaId(), "");
    const clipName = safeCall(() => clip.GetName(), "未命名时间线");
    const clipType = getClipType(clip);

    let timelineRecord = matchedByMediaId.get(mediaId) || null;
    if (!timelineRecord && clipType.includes("timeline")) {
      timelineRecord = timelines.find((item) => item.name === clipName && !usedTimelineIds.has(item.id)) || null;
    }

    if (!timelineRecord && !clipType.includes("timeline")) {
      continue;
    }

    if (!timelineRecord) {
      continue;
    }

    usedTimelineIds.add(timelineRecord.id);
    entries.push({
      id: timelineRecord.id,
      name: timelineRecord.name,
      folderId,
      mediaPoolItemId: timelineRecord.mediaPoolItemId
    });
  }

  return entries;
}

function getRenderPresets(project) {
  return normalizeList(safeCall(() => project.GetRenderPresetList(), [])).map((preset) => {
    if (typeof preset === "string") {
      return {
        id: preset,
        label: preset
      };
    }

    const name = preset && (preset.name || preset.Name || preset.presetName || preset.PresetName);
    return {
      id: name || "unknown",
      label: name || "未知预设"
    };
  });
}

function getRenderFormats(project) {
  const formats = safeCall(() => project.GetRenderFormats(), {});
  return Object.entries(formats || {}).map(([formatId, extension]) => ({
    id: formatId,
    label: `${formatId.toUpperCase()} (${extension})`,
    extension: String(extension)
  }));
}

function getRenderCodecs(project, format) {
  const codecs = safeCall(() => project.GetRenderCodecs(format), {});
  return Object.entries(codecs || {}).map(([label, id]) => ({
    id: String(id),
    label
  }));
}

function getRenderResolutions(project, format, codec) {
  return normalizeList(safeCall(() => project.GetRenderResolutions(format, codec), [])).map((item) => ({
    width: Number(item.Width || item.width || 0),
    height: Number(item.Height || item.height || 0)
  })).filter((item) => item.width > 0 && item.height > 0);
}

function getFrameRateOptions(project) {
  const commonRates = [23.976, 24, 25, 29.97, 30, 50, 59.94, 60];
  const timelineRate = Number(safeCall(() => project.GetCurrentTimeline().GetSetting("timelineFrameRate"), 0));
  if (timelineRate && !commonRates.includes(timelineRate)) {
    commonRates.push(timelineRate);
  }

  return commonRates.map((value) => ({
    id: String(value),
    label: `${value} fps`,
    value
  })).sort((left, right) => left.value - right.value);
}

function getRenderOptions() {
  const { project } = getProjectContext();
  const currentFormatAndCodec = safeCall(() => project.GetCurrentRenderFormatAndCodec(), {});
  const formats = getRenderFormats(project);
  const activeFormat = currentFormatAndCodec.format || (formats[0] ? formats[0].id : "");
  const codecs = activeFormat ? getRenderCodecs(project, activeFormat) : [];
  const activeCodec = currentFormatAndCodec.codec || (codecs[0] ? codecs[0].id : "");
  const resolutions = activeFormat ? getRenderResolutions(project, activeFormat, activeCodec) : [];

  return {
    presets: getRenderPresets(project),
    formats,
    codecs,
    resolutions,
    frameRates: getFrameRateOptions(project),
    currentFormat: activeFormat,
    currentCodec: activeCodec
  };
}

function sanitizeForWindowsFileName(value) {
  return String(value)
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "_")
    .replace(/\s+/g, " ")
    .trim();
}

function formatDateToken(date) {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${yyyy}${mm}${dd}`;
}

function formatTimeToken(date) {
  const hh = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  const ss = String(date.getSeconds()).padStart(2, "0");
  return `${hh}${mm}${ss}`;
}

function renderFileName(template, projectName, timelineName, index) {
  const now = new Date();
  const compiled = String(template || "{timeline}")
    .replaceAll("{timeline}", timelineName)
    .replaceAll("{project}", projectName)
    .replaceAll("{date}", formatDateToken(now))
    .replaceAll("{time}", formatTimeToken(now))
    .replaceAll("{index}", String(index).padStart(2, "0"));

  return sanitizeForWindowsFileName(compiled) || sanitizeForWindowsFileName(timelineName) || `timeline_${index}`;
}

function buildRenderSettings(settings, targetDir, customName) {
  return {
    SelectAllFrames: true,
    TargetDir: targetDir,
    CustomName: customName,
    ExportVideo: settings.exportVideo,
    ExportAudio: settings.exportAudio,
    FormatWidth: settings.resolution.width,
    FormatHeight: settings.resolution.height,
    FrameRate: settings.frameRate,
    AudioCodec: settings.audioCodec || undefined,
    AudioBitDepth: settings.audioBitDepth || undefined,
    AudioSampleRate: settings.audioSampleRate || undefined,
    ExportAlpha: settings.exportAlpha || false
  };
}

function resolveTimelineById(project, timelineId) {
  const count = safeCall(() => project.GetTimelineCount(), 0);
  for (let index = 1; index <= count; index += 1) {
    const timeline = safeCall(() => project.GetTimelineByIndex(index), null);
    if (!timeline) {
      continue;
    }

    if (safeCall(() => timeline.GetUniqueId(), "") === timelineId) {
      return timeline;
    }
  }

  return null;
}

async function runBatchExport(payload) {
  const { app, project } = getProjectContext();
  const version = getVersionInfo();

  if (!version.isStudio || version.majorVersion < 19) {
    throw new Error("该插件仅支持 DaVinci Resolve Studio 19 及以上版本。");
  }

  if (safeCall(() => project.IsRenderingInProgress(), false)) {
    throw new Error("当前已有渲染任务正在执行，请等待完成或手动停止后再批量导出。");
  }

  const selectedTimelines = Array.isArray(payload.selectedTimelines) ? payload.selectedTimelines : [];
  if (selectedTimelines.length === 0) {
    throw new Error("请至少选择一条时间线。");
  }

  if (!payload.outputDirectory) {
    throw new Error("请先选择导出目录。");
  }

  const originalTimeline = safeCall(() => project.GetCurrentTimeline(), null);
  const projectName = safeCall(() => project.GetName(), "UntitledProject");
  const jobIds = [];
  const results = [];

  safeCall(() => app.OpenPage("deliver"), false);

  for (let index = 0; index < selectedTimelines.length; index += 1) {
    const entry = selectedTimelines[index];
    const timeline = resolveTimelineById(project, entry.id);

    if (!timeline) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: "未在当前工程中定位到时间线对象。"
      });
      continue;
    }

    const switched = safeCall(() => project.SetCurrentTimeline(timeline), false);
    if (!switched) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: "切换到目标时间线失败。"
      });
      continue;
    }

    if (payload.settings.presetName) {
      const presetLoaded = safeCall(() => project.LoadRenderPreset(payload.settings.presetName), false);
      if (!presetLoaded) {
        results.push({
          timelineName: entry.name,
          success: false,
          reason: `加载预设失败：${payload.settings.presetName}`
        });
        continue;
      }
    }

    const renderModeSet = safeCall(() => project.SetCurrentRenderMode(1), false);
    if (!renderModeSet) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: "设置单文件渲染模式失败。"
      });
      continue;
    }

    const formatSet = safeCall(
      () => project.SetCurrentRenderFormatAndCodec(payload.settings.format, payload.settings.codec),
      false
    );

    if (!formatSet) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: `设置导出格式/编码器失败：${payload.settings.format}/${payload.settings.codec}`
      });
      continue;
    }

    const fileName = renderFileName(payload.namingTemplate, projectName, entry.name, index + 1);
    const renderSettings = buildRenderSettings(payload.settings, payload.outputDirectory, fileName);
    const renderSettingApplied = safeCall(() => project.SetRenderSettings(renderSettings), false);

    if (!renderSettingApplied) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: "应用导出设置失败。"
      });
      continue;
    }

    const jobId = safeCall(() => project.AddRenderJob(), "");
    if (!jobId) {
      results.push({
        timelineName: entry.name,
        success: false,
        reason: "添加 Render Queue 任务失败。"
      });
      continue;
    }

    jobIds.push(jobId);
    results.push({
      timelineName: entry.name,
      success: true,
      jobId,
      outputName: fileName
    });
  }

  if (originalTimeline) {
    safeCall(() => project.SetCurrentTimeline(originalTimeline), false);
  }

  if (jobIds.length > 0) {
    const started = safeCall(() => project.StartRendering(jobIds), false);
    if (!started) {
      throw new Error("任务已加入队列，但启动渲染失败，请到 Deliver 页检查。");
    }
  }

  return {
    startedJobs: jobIds.length,
    succeeded: results.filter((item) => item.success).length,
    failed: results.filter((item) => !item.success).length,
    results
  };
}

const bridge = {
  async getEnvironment() {
    const version = getVersionInfo();
    const projectName = safeCall(() => getProjectContext().project.GetName(), "");
    return {
      ...version,
      projectName,
      pluginId
    };
  },
  async getMediaPoolTree() {
    const { project } = getProjectContext();
    const mediaPool = project.GetMediaPool();
    return buildFolderTree(mediaPool.GetRootFolder());
  },
  async getFolderTimelines(folderId) {
    return listTimelinesInFolder(folderId);
  },
  async getRenderOptions() {
    return getRenderOptions();
  },
  async chooseOutputDirectory() {
    return ipcRenderer.invoke("dv-batch-export:select-output-directory");
  },
  async runBatchExport(payload) {
    return runBatchExport(payload);
  }
};

contextBridge.exposeInMainWorld("resolveBridge", bridge);
