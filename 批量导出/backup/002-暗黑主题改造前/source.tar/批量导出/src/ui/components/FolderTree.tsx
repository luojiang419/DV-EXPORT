import type { MediaPoolFolderNode } from "../../types/models";

interface FolderTreeProps {
  tree: MediaPoolFolderNode | null;
  selectedFolderId: string | null;
  onSelect(folderId: string): void;
}

function FolderBranch({
  node,
  selectedFolderId,
  onSelect,
  depth
}: {
  node: MediaPoolFolderNode;
  selectedFolderId: string | null;
  onSelect(folderId: string): void;
  depth: number;
}) {
  return (
    <li>
      <button
        className={`folder-tree__item ${selectedFolderId === node.id ? "is-active" : ""}`}
        style={{ paddingLeft: `${depth * 14 + 14}px` }}
        onClick={() => onSelect(node.id)}
        type="button"
      >
        <span className="folder-tree__icon">▸</span>
        <span>{node.name}</span>
      </button>
      {node.children.length > 0 ? (
        <ul className="folder-tree__list">
          {node.children.map((child) => (
            <FolderBranch
              key={child.id}
              node={child}
              selectedFolderId={selectedFolderId}
              onSelect={onSelect}
              depth={depth + 1}
            />
          ))}
        </ul>
      ) : null}
    </li>
  );
}

export function FolderTree({ tree, selectedFolderId, onSelect }: FolderTreeProps) {
  if (!tree) {
    return <div className="empty-panel">正在读取媒体池目录...</div>;
  }

  return (
    <ul className="folder-tree__list">
      <FolderBranch node={tree} selectedFolderId={selectedFolderId} onSelect={onSelect} depth={0} />
    </ul>
  );
}
